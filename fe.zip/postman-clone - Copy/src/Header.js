import React from 'react';
import { ReactComponent as Logo } from './assets/logo.svg'; // Adjust the path as needed

const Header = () => {
    return (
        <header style={styles.header}>
            <Logo style={styles.logo} />
            <h1 style={styles.title}>Allegro Testing Tool</h1>
        </header>
    );
};

const styles = {
    header: {
        backgroundColor: '#007bff',
        color: '#fff',
        padding: '0 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',
        height: '60px', // Example height, adjust as needed
    },
    logo: {
        position: 'absolute',
        left: '20px',
        height: '100%',
        width: 'auto',
    },
    title: {
        margin: 0,
        fontSize: '24px',
        position: 'absolute',
        left: '50%',
        transform: 'translateX(-50%)',
    },
};

export default Header;
