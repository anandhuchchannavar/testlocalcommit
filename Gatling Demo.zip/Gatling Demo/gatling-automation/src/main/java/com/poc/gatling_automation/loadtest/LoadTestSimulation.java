package com.poc.gatling_automation.loadtest;


import io.gatling.javaapi.core.*;
import io.gatling.javaapi.http.HttpDsl;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.http;

public class LoadTestSimulation extends Simulation {

    public LoadTestSimulation() {
        // Fetching parameters from system properties
        String baseUrl = System.getProperty("gatling.baseUrl", "http://localhost:8080");
        String endpoint = System.getProperty("gatling.endpoint", "/test-api");
        int numOfUsers = Integer.parseInt(System.getProperty("gatling.numOfUsers", "10"));
        int time = Integer.parseInt(System.getProperty("gatling.time", "20"));
        String requestBody = System.getProperty("gatling.requestBody", "{}");

        setUp(
            scenario("Load Test Scenario")
                .exec(http("API Request")
                    .post(baseUrl + endpoint)
                    .header("Content-Type", "application/json")
                    .body(StringBody(requestBody))
                )
                .injectOpen(rampUsers(numOfUsers).during(time))
        ).protocols(HttpDsl.http.baseUrl(baseUrl));
    }
}

//import io.gatling.javaapi.core.*;
//import io.gatling.javaapi.http.HttpDsl;
//
//import java.util.List;
//
//import static io.gatling.javaapi.core.CoreDsl.*;
//import static io.gatling.javaapi.http.HttpDsl.http;
//
//public class LoadTestSimulation extends Simulation {
//
//    public LoadTestSimulation(List<String> userRequests, String baseUrl, String endpoint, int numOfUsers, int time) {
//        setUp(
//            scenario("Load Test Scenario")
//                .exec(http("API Request")
//                    .post(baseUrl + endpoint)
//                    .header("Content-Type", "application/json")
//                    .body(StringBody(userRequests.get(0))) // Sending first user's request
//                )
//                .injectOpen(rampUsers(numOfUsers).during(time))
//        ).protocols(HttpDsl.http.baseUrl(baseUrl));
//    }
//}



//import io.gatling.javaapi.core.*;
//import io.gatling.javaapi.http.HttpProtocolBuilder;
//
//import static io.gatling.javaapi.core.CoreDsl.*;
//import static io.gatling.javaapi.http.HttpDsl.*;
//
//import java.nio.file.Files;
//import java.nio.file.Paths;
//import java.util.Map;
//
//public class LoadTestSimulation extends Simulation {
//
//    private static final String BASE_URL = "https://example.com"; // Default base URL
//
//    public LoadTestSimulation() {
//        try {
//            // Read request parameters from JSON file (if exists)
//            String jsonConfig = new String(Files.readAllBytes(Paths.get("target/gatling/request.json")));
//            Map<String, Object> config = new com.fasterxml.jackson.databind.ObjectMapper().readValue(jsonConfig, Map.class);
//
//            // Extract values from config or use defaults
//            String baseUrl = config.getOrDefault("baseurl", BASE_URL).toString();
//            String endpoint = config.getOrDefault("endpoint", "/api/test").toString();
//            String requestBody = config.getOrDefault("requestBody", "{}").toString();
//            int numberOfUsers = Integer.parseInt(config.getOrDefault("numberOfUsers", "10").toString());
//
//            // Define Gatling HTTP protocol
//            HttpProtocolBuilder httpProtocol = http.baseUrl(baseUrl);
//
//            // Define the load test scenario
//            ScenarioBuilder scn = scenario("API Load Test")
//                    .exec(http("Request")
//                            .post(endpoint)
//                            .header("Content-Type", "application/json")
//                            .body(StringBody(requestBody))
//                            .check(status().is(200)));
//
//            // Configure user injection
//            setUp(
//                scn.injectOpen(atOnceUsers(numberOfUsers))
//            ).protocols(httpProtocol);
//
//        } catch (Exception e) {
//            throw new RuntimeException("Error reading test configuration: " + e.getMessage(), e);
//        }
//    }
//}