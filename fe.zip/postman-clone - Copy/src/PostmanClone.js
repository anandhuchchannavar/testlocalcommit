import React, { useState } from 'react';

const PostmanClone = () => {
    const [requestBody, setRequestBody] = useState('');
    const [responseBody, setResponseBody] = useState('');
    const [headers, setHeaders] = useState([{ key: '', value: '' }]);
    const [selectedModes, setSelectedModes] = useState([]);
    const [method, setMethod] = useState('GET');
    const [url, setUrl] = useState('');

    const handleRequestBodyChange = (e) => setRequestBody(e.target.value);
    const handleResponseBodyChange = (e) => setResponseBody(e.target.value);

    const handleCheckboxChange = (e) => {
        const { value, checked } = e.target;
        setSelectedModes((prev) =>
            checked ? [...prev, value] : prev.filter((mode) => mode !== value)
        );
    };

    const handleDownloadRequest = () => downloadFile(requestBody, 'request.txt');
    const handleDownloadResponse = () => downloadFile(responseBody, 'response.txt');

    const downloadFile = (content, filename) => {
        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleSubmit = () => {
        const modeHeader = selectedModes.join(',');
        const updatedHeaders = [...headers, { key: 'mode', value: modeHeader }];

        // Convert headers array to object
        const headersObject = updatedHeaders.reduce((acc, header) => {
            if (header.key) acc[header.key] = header.value;
            return acc;
        }, {});

        // Make the HTTP request
        fetch(url, {
            method,
            headers: headersObject,
            body: method === 'GET' ? null : requestBody, // Only include body for methods other than GET
        })
            .then((response) => response.text())
            .then((data) => setResponseBody(data))
            .catch((error) => console.error('Error:', error));
    };

    return (
        <div style={styles.container}>
            <div style={styles.topBar}>
                <select
                    style={styles.methodSelect}
                    value={method}
                    onChange={(e) => setMethod(e.target.value)}
                >
                    <option value="GET">GET</option>
                    <option value="POST">POST</option>
                    <option value="PUT">PUT</option>
                    <option value="DELETE">DELETE</option>
                </select>
                <input
                    type="text"
                    placeholder="Enter URL"
                    style={styles.urlInput}
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                />
                <button style={styles.submitButton} onClick={handleSubmit}>
                    Submit
                </button>
            </div>

            <div style={styles.checkboxContainer}>
                Choreox Services :    
                {['Mode1', 'Mode2', 'Mode3', 'Mode4', 'Mode5'].map((mode) => (
                    <label key={mode} style={styles.checkboxLabel}>
                        <input
                            type="checkbox"
                            value={mode}
                            onChange={handleCheckboxChange}
                            style={styles.checkbox}
                        />
                        {mode}
                    </label>
                ))}
            </div>

            <div style={styles.headersContainer}>
                {headers.map((header, index) => (
                    <div key={index} style={styles.headerRow}>
                        <input
                            type="text"
                            placeholder="Header Key"
                            value={header.key}
                            onChange={(e) => {
                                const newHeaders = [...headers];
                                newHeaders[index].key = e.target.value;
                                setHeaders(newHeaders);
                            }}
                            style={styles.headerInput}
                        />
                        <input
                            type="text"
                            placeholder="Header Value"
                            value={header.value}
                            onChange={(e) => {
                                const newHeaders = [...headers];
                                newHeaders[index].value = e.target.value;
                                setHeaders(newHeaders);
                            }}
                            style={styles.headerInput}
                        />
                        <button
                            onClick={() => {
                                const newHeaders = headers.filter((_, i) => i !== index);
                                setHeaders(newHeaders);
                            }}
                            style={styles.deleteButton}
                        >
                            Delete
                        </button>
                    </div>
                ))}
                <button
                    onClick={() => setHeaders([...headers, { key: '', value: '' }])}
                    style={styles.addHeaderButton}
                >
                    Add Header
                </button>
            </div>

            <div style={styles.bodyContainer}>
                <div style={styles.bodySection}>
                    <textarea
                        placeholder="Request Body"
                        value={requestBody}
                        onChange={handleRequestBodyChange}
                        style={styles.textArea}
                    />
                    <button onClick={handleDownloadRequest} style={styles.downloadButton}>
                        Download Request
                    </button>
                </div>
                <div style={styles.bodySection}>
                    <textarea
                        placeholder="Response Body"
                        value={responseBody}
                        onChange={handleResponseBodyChange}
                        style={styles.textArea}
                    />
                    <button onClick={handleDownloadResponse} style={styles.downloadButton}>
                        Download Response
                    </button>
                </div>
            </div>
        </div>
    );
};

const styles = {
    container: {
        display: 'flex',
        flexDirection: 'column',
        height: '100vh',
        padding: '10px',
    },
    topBar: {
        display: 'flex',
        alignItems: 'center',
        marginBottom: '10px',
    },
    methodSelect: {
        padding: '8px',
        marginRight: '10px',
    },
    urlInput: {
        flex: 1,
        padding: '8px',
        marginRight: '10px',
    },
    submitButton: {
        padding: '8px 16px',
        backgroundColor: '#007bff',
        color: '#fff',
        border: 'none',
        cursor: 'pointer',
    },
    checkboxContainer: {
        display: 'flex',
        alignItems: 'center',
        marginBottom: '10px',
        marginTop: '10px',
    },
    checkboxLabel: {
        marginRight: '15px',
        display: 'flex',
        alignItems: 'center',
    },
    checkbox: {
        marginRight: '5px',
    },
    headersContainer: {
        marginBottom: '10px',
    },
    headerRow: {
        display: 'flex',
        marginBottom: '5px',
    },
    headerInput: {
        flex: 1,
        padding: '8px',
        marginRight: '5px',
    },
    deleteButton: {
        padding: '8px 16px',
        backgroundColor: '#dc3545',
        color: '#fff',
        border: 'none',
        cursor: 'pointer',
    },
    addHeaderButton: {
        padding: '8px 16px',
        backgroundColor: '#28a745',
        color: '#fff',
        border: 'none',
        cursor: 'pointer',
    },
    bodyContainer: {
        display: 'flex',
        flex: 1,
        justifyContent: 'space-between',
    },
    bodySection: {
        display: 'flex',
        flexDirection: 'column',
        flex: 1,
        margin: '0 5px',
    },
    textArea: {
        flex: 1,
        padding: '10px',
        resize: 'none',
        fontSize: '16px',
        borderRadius: '4px',
        border: '1px solid #ccc',
    },
    downloadButton: {
        marginTop: '10px',
        padding: '8px 16px',
        backgroundColor: '#007bff',
        color: '#fff',
        border: 'none',
        cursor: 'pointer',
        alignSelf: 'flex-start',
    },
};

export default PostmanClone;
