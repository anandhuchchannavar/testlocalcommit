package com.poc.gatling_automation.model;
import lombok.Data;

@Data
public class LoadTestRequest {
    private String username;
    private String password;
    private String baseUrl;
    private String endpoint;
    private int numberOfUsers;
    private int time;
}