package com.poc.gatling_automation.service;
import com.poc.gatling_automation.model.LoadTestRequest;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class CsvParserService {
    public static List<LoadTestRequest> parseCsv(MultipartFile file) {
        List<LoadTestRequest> requests = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8));
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader())) {

            for (CSVRecord csvRecord : csvParser) {
                LoadTestRequest request = new LoadTestRequest();
                request.setUsername(csvRecord.get("username"));
                request.setPassword(csvRecord.get("password"));
                request.setBaseUrl(csvRecord.get("baseurl"));
                request.setEndpoint(csvRecord.get("endpoint"));
                request.setNumberOfUsers(Integer.parseInt(csvRecord.get("numberofusers")));
                request.setTime(Integer.parseInt(csvRecord.get("time")));

                requests.add(request);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return requests;
    }
}