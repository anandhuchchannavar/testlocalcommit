import React, { useState } from "react";
import axios from "axios";
import Papa from "papaparse";
import { ClipLoader } from "react-spinners";

function App() {
  const [requestData, setRequestData] = useState("");
  const [reportUrl, setReportUrl] = useState("");
  const [loading, setLoading] = useState(false);

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    Papa.parse(file, {
      header: true,
      complete: (results) => {
        setRequestData(JSON.stringify(results.data[0], null, 2)); // Format JSON nicely
      },
    });
  };

  // const handleSubmit = async () => {
  //   try {
  //     setLoading(true);
  //     const parsedData = JSON.parse(requestData);
  //     const response = await axios.post("http://localhost:8080/api/loadtest/run", parsedData);
  //     const reportPath = response.data;
  //     console.log("Report Path is :", reportPath);
  //     //setReportUrl(`http://localhost:8080${reportPath}`);
  //     setReportUrl(reportPath); // Store raw HTML content
  //   } catch (error) {
  //     console.error("Error:", error);
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  // const handleSubmit = async () => {
  //   try {
  //     setLoading(true);
  //     const parsedData = JSON.parse(requestData);
  //     const response = await axios.post("http://localhost:8080/api/loadtest/run", parsedData, {
  //       headers: { "Accept": "text/html" }, // Ensure backend returns HTML
  //     });
  
  //     if (response.data) {
  //       setReportUrl(response.data); // Store raw HTML content
  //     }
  //   } catch (error) {
  //     console.error("Error:", error);
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  const handleSubmit = async () => {
    try {
      setLoading(true);
      const parsedData = JSON.parse(requestData);
      const response = await axios.post("http://localhost:8080/api/loadtest/run", parsedData);
  
      if (response.data) {
        setReportUrl(`http://localhost:8080/api/loadtest/report?folder=${response.data}`); // Folder name from backend
      }
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };
  const downloadPDF = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/loadtest/download-pdf", {
        responseType: "blob",
      });
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", "gatling_report.pdf");
      document.body.appendChild(link);
      link.click();
    } catch (error) {
      console.error("Error downloading PDF:", error);
    }
  };

  return (
    <div style={styles.container}>
      {/* Request Panel */}
      <div style={styles.panel}>
        <h2>Load Test Input</h2>
        <input type="file" accept=".csv" onChange={handleFileUpload} style={styles.fileInput} />
        <textarea
          rows="10"
          placeholder="Enter JSON request here..."
          value={requestData}
          onChange={(e) => setRequestData(e.target.value)}
          style={styles.textarea}
        />
        <button onClick={handleSubmit} style={styles.button} disabled={loading}>
          {loading ? <ClipLoader size={15} color={"#fff"} /> : "Run Load Test"}
        </button>
      </div>

      {/* Response Panel */}
      <div style={styles.panel}>
        <h2>Gatling Report</h2>
        {loading ? (
          <div style={styles.loaderContainer}>
            <ClipLoader size={50} color={"#007bff"} />
            <p>Running Load Test...</p>
          </div>
        ) : (
          reportUrl && (
            <>
              <iframe src ={reportUrl} width="100%" height="500px" title="Gatling Report" />
              <button onClick={downloadPDF} style={styles.button}>Download as PDF</button>
            </>
          )
        )}
      </div>
    </div>
  );
}

const styles = {
  container: {
    display: "flex",
    height: "100vh",
    padding: "20px",
    backgroundColor: "#f4f4f4",
  },
  panel: {
    flex: 1,
    padding: "20px",
    backgroundColor: "#fff",
    margin: "10px",
    borderRadius: "8px",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
    display: "flex",
    flexDirection: "column",
  },
  fileInput: {
    marginBottom: "10px",
  },
  textarea: {
    width: "100%",
    height: "200px",
    fontSize: "16px",
    padding: "10px",
    borderRadius: "5px",
    border: "1px solid #ccc",
    resize: "none",
  },
  button: {
    marginTop: "10px",
    padding: "10px",
    backgroundColor: "#007bff",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "16px",
  },
  loaderContainer: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
    color: "#333",
  },
};

export default App;
