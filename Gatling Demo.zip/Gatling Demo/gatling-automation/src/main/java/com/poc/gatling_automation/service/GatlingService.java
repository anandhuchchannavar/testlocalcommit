package com.poc.gatling_automation.service;


import io.gatling.app.Gatling;
import io.gatling.core.config.GatlingPropertiesBuilder;

import java.io.File;
import java.util.List;

import com.poc.gatling_automation.loadtest.LoadTestSimulation;

public class GatlingService {
    private static final String GATLING_RESULTS_DIR = "C:/Users/anand/Downloads/gatling-automation/gatling-automation/results";

    public String runGatlingTest(String requestBody, String baseUrl, String endpoint, int numOfUsers, int time) {
        System.setProperty("gatling.baseUrl", baseUrl);
        System.setProperty("gatling.endpoint", endpoint);
        System.setProperty("gatling.numOfUsers", String.valueOf(numOfUsers));
        System.setProperty("gatling.time", String.valueOf(time));
        System.setProperty("gatling.requestBody", requestBody);

        GatlingPropertiesBuilder props = new GatlingPropertiesBuilder()
                .simulationClass(LoadTestSimulation.class.getName());

        Gatling.fromMap(props.build());

        return getLatestReport();
    }

    private String getLatestReport() {
        File resultsDir = new File(GATLING_RESULTS_DIR);
        if (resultsDir.exists() && resultsDir.isDirectory()) {
            File[] subDirs = resultsDir.listFiles(File::isDirectory);
            if (subDirs != null && subDirs.length > 0) {
                File latestRunDir = subDirs[subDirs.length - 1]; // Get latest execution folder
               // return latestRunDir.getAbsolutePath();
                return latestRunDir.getName();
            }
        }
        return null;
    }
}



//import com.poc.gatling_automation.loadtest.LoadTestSimulation;
//import io.gatling.app.Gatling;
//import io.gatling.core.config.GatlingPropertiesBuilder;
//
//import java.io.File;
//import java.nio.file.Files;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.util.List;
//
//public class GatlingService {
//    private static final String GATLING_RESULTS_DIR = "target/gatling";
//
//    public String runGatlingTest(List<String> userRequests, String baseUrl, String endpoint, int numOfUsers, int time) {
//        GatlingPropertiesBuilder props = new GatlingPropertiesBuilder()
//                .simulationClass(LoadTestSimulation.class.getName());
//
//        new LoadTestSimulation(userRequests, baseUrl, endpoint, numOfUsers, time);
//
//        Gatling.fromMap(props.build());
//
//        return getLatestReport();
//    }
//
//    private String getLatestReport() {
//        File resultsDir = new File(GATLING_RESULTS_DIR);
//        if (resultsDir.exists() && resultsDir.isDirectory()) {
//            File[] subDirs = resultsDir.listFiles(File::isDirectory);
//            if (subDirs != null && subDirs.length > 0) {
//                File latestRunDir = subDirs[subDirs.length - 1]; // Get the most recent execution folder
//                return latestRunDir.getAbsolutePath();
//            }
//        }
//        return null;
//    }
//}