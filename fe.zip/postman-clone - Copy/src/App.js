import React from 'react';
import PostmanClone from './PostmanClone';
import Header from './Header';
import Footer from './Footer';

function App() {
    return (
        <div className="App" style={styles.appContainer}>
            <Header />
            <main style={styles.mainContent}>
                <PostmanClone />
            </main>
            <Footer />
        </div>
    );
}

const styles = {
    appContainer: {
        display: 'flex',
        flexDirection: 'column',
        minHeight: '100vh',
    },
    mainContent: {
        flex: 1,
        padding: '20px',
    },
};

export default App;
