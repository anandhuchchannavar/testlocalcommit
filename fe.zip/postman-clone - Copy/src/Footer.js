import React from 'react';

const Footer = () => {
    return (
        <footer style={styles.footer}>
            <p style={styles.text}>© 2024 Synchrony.com. All rights reserved.</p>
        </footer>
    );
};

const styles = {
    footer: {
        backgroundColor: '#f1f1f1',
        padding: '10px 20px',
        textAlign: 'center',
        marginTop: '20px',
        borderTop: '1px solid #ccc',
    },
    text: {
        margin: 0,
        fontSize: '14px',
        color: '#333',
    },
};

export default Footer;
