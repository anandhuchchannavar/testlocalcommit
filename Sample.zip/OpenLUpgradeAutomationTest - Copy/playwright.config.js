module.exports = {
  timeout: 60000,
  retries: 0,
  reporter: [['html', { outputFolder: 'playwright-report' }]],
  testDir: './tests',
};
