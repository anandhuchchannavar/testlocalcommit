package com.poc.gatling_automation.controller;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;
import com.poc.gatling_automation.model.LoadTestRequest;
import com.poc.gatling_automation.service.CsvParserService;
import com.poc.gatling_automation.service.GatlingService;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/loadtest")
public class GatlingController {
	
	private static final String GATLING_RESULTS_DIR = "results/"; // Path to the results folder

	
	 private final GatlingService gatlingService = new GatlingService();

	 @PostMapping(value = "/run", consumes = {"application/json", "multipart/form-data"})
	    public ResponseEntity<String> runLoadTest(
	            @RequestPart(value = "file", required = false) MultipartFile file,
	            @RequestBody(required = false) LoadTestRequest request) {

	        String reportPath;
	        String requestBody ="Anand";
	        if (file != null) {
	            List<LoadTestRequest> requests = CsvParserService.parseCsv(file);
	            List<String> jsonRequests = requests.stream()
	                    .map(r -> String.format("{\"username\":\"%s\",\"password\":\"%s\"}", r.getUsername(), r.getPassword()))
	                    .collect(Collectors.toList());
	            
	            reportPath = gatlingService.runGatlingTest(requestBody, requests.get(0).getBaseUrl(), requests.get(0).getEndpoint(), requests.get(0).getNumberOfUsers(), requests.get(0).getTime());
	        } else if (request != null) {
	            String jsonRequest = String.format("{\"username\":\"%s\",\"password\":\"%s\"}", request.getUsername(), request.getPassword());
	            reportPath = gatlingService.runGatlingTest(requestBody, request.getBaseUrl(), request.getEndpoint(), request.getNumberOfUsers(), request.getTime());
	        } else {
	            return ResponseEntity.badRequest().build();
	        }

	        if (reportPath == null) {
	        	System.out.println("Report path is not present");
	            return ResponseEntity.internalServerError().body(null);
	        }

	        try {
	            //Path filePath = Paths.get(reportPath, "index.html"); // Get index.html (main report file)
	        	Path filePath = Paths.get(reportPath);
	        	Resource resource = new UrlResource(filePath.toUri());
	            //String content = Files.readString(filePath);
//	            return ResponseEntity.ok()
//	                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"gatling-report.html\"")
//	                    .contentType(MediaType.TEXT_HTML)
//	                    .body(resource);
	            
	            return ResponseEntity.ok(reportPath);
	                   
	            //.body(content);
	        } catch (Exception e) {
	        	e.printStackTrace();
	            return ResponseEntity.internalServerError().build();
	        }
	    }
	 
	 
//	    @PostMapping(value = "/run", consumes = {"application/json", "multipart/form-data"})
//	    public ResponseEntity<Resource> runLoadTest(
//	            @RequestPart(value = "file", required = false) MultipartFile file,
//	            @RequestBody(required = false) LoadTestRequest request) {
//
//	        String reportPath;
//	        if (file != null) {
//	            List<LoadTestRequest> requests = CsvParserService.parseCsv(file);
//	            List<String> jsonRequests = requests.stream()
//	                    .map(r -> String.format("{\"username\":\"%s\",\"password\":\"%s\"}", r.getUsername(), r.getPassword()))
//	                    .collect(Collectors.toList());
//	            
//	            reportPath = gatlingService.runGatlingTest(jsonRequests, requests.get(0).getBaseUrl(), requests.get(0).getEndpoint(), requests.get(0).getNumberOfUsers(), requests.get(0).getTime());
//	        } else if (request != null) {
//	            String jsonRequest = String.format("{\"username\":\"%s\",\"password\":\"%s\"}", request.getUsername(), request.getPassword());
//	            reportPath = gatlingService.runGatlingTest(Collections.singletonList(jsonRequest), request.getBaseUrl(), request.getEndpoint(), request.getNumberOfUsers(), request.getTime());
//	        } else {
//	            return ResponseEntity.badRequest().build();
//	        }
//
//	        if (reportPath == null) {
//	            return ResponseEntity.internalServerError().body(null);
//	        }
//
//	        try {
//	            Path filePath = Paths.get(reportPath, "index.html"); // Get index.html (main report file)
//	            Resource resource = new UrlResource(filePath.toUri());
//
//	            return ResponseEntity.ok()
//	                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"gatling-report.html\"")
//	                    .contentType(MediaType.TEXT_HTML)
//	                    .body(resource);
//	        } catch (Exception e) {
//	            return ResponseEntity.internalServerError().build();
//	        }
//	    }


//    @PostMapping("/run")
//    public ResponseEntity<String> runLoadTest(@RequestPart(value = "file", required = false) MultipartFile file,
//                                              @RequestBody(required = false) Map<String, Object> requestParams) {
//        try {
//            if (file != null && !file.isEmpty()) {
//                File csvFile = new File("target/gatling/request.csv");
//                file.transferTo(csvFile);
//            }
//
//            if (requestParams != null && !requestParams.isEmpty()) {
//                File requestFile = new File("target/gatling/request.json");
//                requestFile.getParentFile().mkdirs(); // Ensure directory exists
//                Files.write(requestFile.toPath(), requestParams.toString().getBytes());
//            }
//
//            // Run Gatling as a process
//            ProcessBuilder processBuilder = new ProcessBuilder("mvn", "gatling:test");
//            processBuilder.redirectErrorStream(true);
//            Process process = processBuilder.start();
//            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
//            StringBuilder output = new StringBuilder();
//            String line;
//            while ((line = reader.readLine()) != null) {
//                output.append(line).append("\n");
//            }
//            process.waitFor();
//
//            // Locate latest Gatling report
//            File reportDir = new File("target/gatling");
//            File[] reports = reportDir.listFiles(File::isDirectory);
//            if (reports == null || reports.length == 0) {
//                return ResponseEntity.internalServerError().body("No Gatling report found.");
//            }
//
//            File latestReport = reports[reports.length - 1];
//            String reportPath = "/gatling-reports/" + latestReport.getName() + "/index.html";
//
//            return ResponseEntity.ok(reportPath);
//        } catch (Exception e) {
//            return ResponseEntity.internalServerError().body("Error executing Gatling: " + e.getMessage());
//        }
//    }

//    @GetMapping("/download-pdf")
//    public ResponseEntity<Resource> downloadReportAsPDF() {
//        try {
//            File pdfFile = new File("target/gatling_report.pdf");
//            if (!pdfFile.exists()) {
//                return ResponseEntity.notFound().build();
//            }
//
//            Resource fileResource = new FileSystemResource(pdfFile);
//            return ResponseEntity.ok()
//                    .contentType(MediaType.APPLICATION_PDF)
//                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=gatling_report.pdf")
//                    .body(fileResource);
//        } catch (Exception e) {
//            return ResponseEntity.internalServerError().build();
//        }
//    }
    
	 
	 @GetMapping("/download-pdf")
	    public ResponseEntity<byte[]> downloadPdf(@RequestParam(required = false) String folder) {
	    	
	        try {
	        	
	        	// If no folder is specified, find the latest folder based on creation date
	            if (folder == null || folder.isEmpty()) {
	                folder = getLatestReportFolder();
	            }
	            // Read the index.html file from the Gatling report folder
	            Path filePath = Paths.get(GATLING_RESULTS_DIR, folder, "index.html");
	            String htmlContent = Files.readString(filePath);

	            // Convert HTML to PDF
	            ByteArrayOutputStream pdfOutputStream = new ByteArrayOutputStream();
	            PdfRendererBuilder builder = new PdfRendererBuilder();
	            builder.useFastMode();
	            builder.toStream(pdfOutputStream);
	            builder.withHtmlContent(htmlContent, new File(GATLING_RESULTS_DIR + folder).toURI().toString());
	            builder.run();

	            // Return the generated PDF
	            return ResponseEntity.ok()
	                    .contentType(MediaType.APPLICATION_PDF)
	                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=gatling_report.pdf")
	                    .body(pdfOutputStream.toByteArray());

	        } catch (Exception e) {
	            return ResponseEntity.internalServerError().body(null);
	        }
	    }
    
    @PostMapping("/test")
    public String test(@RequestBody String request) {
    	return "Test Endpoint called with request : "+request;
    }
    
    
    @GetMapping("/report")
    public ResponseEntity<Resource> getGatlingReport(@RequestParam(required = false) String folder) {
        try {
            // If no folder is specified, find the latest folder based on creation date
            if (folder == null || folder.isEmpty()) {
                folder = getLatestReportFolder();
            }

            // Load the full Gatling report (index.html) from the latest folder
            Path filePath = Paths.get(GATLING_RESULTS_DIR, folder, "index.html");
            Resource resource = new UrlResource(filePath.toUri());

            return ResponseEntity.ok()
                    .contentType(MediaType.TEXT_HTML)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "inline") // Allows direct viewing in iframe
                    .body(resource);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    // Method to find the most recently created folder
    private String getLatestReportFolder() throws Exception {
        File resultsDir = new File(GATLING_RESULTS_DIR);
        if (!resultsDir.exists() || !resultsDir.isDirectory()) {
            throw new Exception("Results directory not found");
        }

        File[] subDirs = resultsDir.listFiles(File::isDirectory);
        if (subDirs == null || subDirs.length == 0) {
            throw new Exception("No report folders found");
        }

        // Sort directories by last modified time, most recent first
        Arrays.sort(subDirs, Comparator.comparingLong(File::lastModified).reversed());

        // Return the name of the most recent directory
        return subDirs[0].getName();
    }
}
