const { test, expect } = require('@playwright/test');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// ✅ Define old and new endpoint URLs here
const oldUrl = 'https://dummyjson.com/posts/add';
const newUrl = 'https://dummyjson.com/posts/add';

const requestsDir = path.join(__dirname, '../data');


function removeKeysDeep(obj, keysToIgnore) {
    if (Array.isArray(obj)) {
      return obj.map(item => removeKeysDeep(item, keysToIgnore));
    } else if (obj !== null && typeof obj === 'object') {
      return Object.entries(obj).reduce((acc, [key, value]) => {
        if (!keysToIgnore.includes(key)) {
          acc[key] = removeKeysDeep(value, keysToIgnore);
        }
        return acc;
      }, {});
    }
    return obj;
  }
  

async function readJsonBodies() {
  const files = fs.readdirSync(requestsDir);
  return files
    .filter(file => file.endsWith('.json'))
    .map(file => {
      const content = fs.readFileSync(path.join(requestsDir, file), 'utf-8');
      return {
        fileName: file,
        body: JSON.parse(content)
      };
    });
}

test.describe('API Response Comparison', () => {
  test('Compare old and new endpoint responses for all requests', async () => {
    const requests = await readJsonBodies();

    for (const req of requests) {
      const { fileName, body } = req;

      try {
        const [oldRes, newRes] = await Promise.all([
          axios.post(oldUrl, body),
          axios.post(newUrl, body),
        ]);

        const ignoredKeys = ['timestamp', 'id', 'uuid']; // Add any keys you want to ignore

        const cleanOld = removeKeysDeep(oldRes.data, ignoredKeys);
        const cleanNew = removeKeysDeep(newRes.data, ignoredKeys);

        try {
        expect(cleanNew).toEqual(cleanOld);
        } catch (compareError) {
        console.error(`❌ Mismatch in file: ${fileName}`);
        console.error('Old Response (cleaned):', JSON.stringify(cleanOld, null, 2));
        console.error('New Response (cleaned):', JSON.stringify(cleanNew, null, 2));
        throw new Error(`Response mismatch for request file: ${fileName}`);
}

      } catch (err) {
        console.error(`❌ Error processing file: ${fileName}`);
        console.error(err.message);
        throw new Error(`Request failed for file: ${fileName} - ${err.message}`);
      }
    }
  });
});
